import React from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  TrendingUp,
  Target,
  BarChart3,
  Star,
  Play,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Zap,
  Globe,
  Heart,
  ChevronDown,
  Menu,
  Rocket,
  Shield,
  Brain,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";

export default function Index() {
  const [isSmartMatchingOpen, setIsSmartMatchingOpen] = useState(false);
  const [matchingForm, setMatchingForm] = useState({
    brandName: "",
    industry: "",
    budget: "",
    targetAudience: "",
    campaignGoals: "",
    preferredPlatforms: "",
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 glass-effect border-b mobile-nav-transition">
        <div className="container-responsive py-3 md:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 animate-fade-in-scale">
              <div className="w-8 h-8 md:w-10 md:h-10 gradient-brand rounded-lg flex items-center justify-center btn-smooth">
                <Sparkles className="w-5 h-5 md:w-6 md:h-6 text-white" />
              </div>
              <span className="text-lg md:text-xl lg:text-2xl font-bold gradient-text responsive-text">
                InfluenceHub
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-6 xl:space-x-8 animate-fade-in-up">
              <div className="relative group">
                <button
                  className="flex items-center text-sm xl:text-base text-muted-foreground hover:text-foreground transition-all duration-300 focus:outline-none px-3 py-2 h-auto font-medium rounded-lg hover:bg-muted/50 btn-smooth bg-transparent border-none cursor-pointer group"
                  onMouseEnter={() => {}}
                >
                  Features
                  <ChevronDown className="w-4 h-4 ml-1 transition-transform duration-300 group-hover:rotate-180" />
                </button>

                {/* Hover Dropdown */}
                <div className="absolute top-full left-0 mt-2 w-80 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50 bg-background border shadow-lg rounded-lg p-3 transform translate-y-2 group-hover:translate-y-0">
                  {/* Smart Matching - Opens Modal */}
                  <div
                    className="flex items-start space-x-3 p-3 cursor-pointer hover:bg-muted/50 rounded-lg transition-all duration-200 group/item"
                    onClick={() => setIsSmartMatchingOpen(true)}
                  >
                    <div className="w-10 h-10 gradient-brand rounded-lg flex items-center justify-center flex-shrink-0 group-hover/item:scale-110 transition-transform duration-200">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground group-hover/item:text-primary transition-colors">
                        Smart Matching
                      </div>
                      <div className="text-sm text-muted-foreground">
                        AI-powered influencer discovery and matching
                      </div>
                    </div>
                    <div className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">
                      Try Now
                    </div>
                  </div>

                  {/* Real-time Analytics */}
                  <div
                    className="flex items-start space-x-3 p-3 cursor-pointer hover:bg-muted/50 rounded-lg transition-all duration-200 group/item"
                    onClick={() => {
                      alert(
                        "📊 Real-time Analytics Dashboard\n\nView comprehensive campaign metrics:\n• Live engagement tracking\n• ROI calculations\n• Performance insights\n• Custom reports\n\nComing in full version!",
                      );
                      document
                        .getElementById("features")
                        ?.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <div className="w-10 h-10 gradient-brand rounded-lg flex items-center justify-center flex-shrink-0 group-hover/item:scale-110 transition-transform duration-200">
                      <BarChart3 className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground group-hover/item:text-primary transition-colors">
                        Real-time Analytics
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Track performance, engagement, and ROI
                      </div>
                    </div>
                    <div className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full font-medium">
                      Dashboard
                    </div>
                  </div>
                  {/* Campaign Management */}
                  <div
                    className="flex items-start space-x-3 p-3 cursor-pointer hover:bg-muted/50 rounded-lg transition-all duration-200 group/item"
                    onClick={() => {
                      alert(
                        "🎯 Campaign Management Suite\n\nStreamline your workflow:\n• Automated campaign creation\n• Content approval system\n• Payment processing\n• Timeline management\n\nManage campaigns efficiently!",
                      );
                      document
                        .getElementById("features")
                        ?.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <div className="w-10 h-10 gradient-brand rounded-lg flex items-center justify-center flex-shrink-0 group-hover/item:scale-110 transition-transform duration-200">
                      <Target className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground group-hover/item:text-primary transition-colors">
                        Campaign Management
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Streamlined workflow and automation
                      </div>
                    </div>
                    <div className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">
                      Workflow
                    </div>
                  </div>
                  {/* Global Reach */}
                  <div
                    className="flex items-start space-x-3 p-3 cursor-pointer hover:bg-muted/50 rounded-lg transition-all duration-200 group/item"
                    onClick={() => {
                      alert(
                        "🌍 Global Influencer Network\n\nWorldwide access:\n• 50+ Countries\n• 25+ Languages\n• All major platforms\n• 100+ Niches\n\nExpand globally!",
                      );
                      document
                        .getElementById("features")
                        ?.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <div className="w-10 h-10 gradient-brand rounded-lg flex items-center justify-center flex-shrink-0 group-hover/item:scale-110 transition-transform duration-200">
                      <Globe className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground group-hover/item:text-primary transition-colors">
                        Global Reach
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Access worldwide influencer network
                      </div>
                    </div>
                    <div className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full font-medium">
                      Worldwide
                    </div>
                  </div>
                  {/* Quality Assurance */}
                  <div
                    className="flex items-start space-x-3 p-3 cursor-pointer hover:bg-muted/50 rounded-lg transition-all duration-200 group/item"
                    onClick={() => {
                      alert(
                        "🛡️ Quality Assurance System\n\nEnsure authenticity:\n• AI fraud detection\n• Follower verification\n• Content quality analysis\n• Brand safety monitoring\n\nProtect your reputation!",
                      );
                      document
                        .getElementById("features")
                        ?.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <div className="w-10 h-10 gradient-brand rounded-lg flex items-center justify-center flex-shrink-0 group-hover/item:scale-110 transition-transform duration-200">
                      <Shield className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground group-hover/item:text-primary transition-colors">
                        Quality Assurance
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Fraud detection and content verification
                      </div>
                    </div>
                    <div className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full font-medium">
                      Security
                    </div>
                  </div>
                  {/* Separator */}
                  <div className="border-t my-2"></div>

                  {/* View All Features */}
                  <div
                    className="flex items-center justify-center space-x-2 p-3 cursor-pointer hover:bg-primary/5 rounded-lg transition-all duration-200 group/item"
                    onClick={() =>
                      document
                        .getElementById("features")
                        ?.scrollIntoView({ behavior: "smooth" })
                    }
                  >
                    <Rocket className="w-5 h-5 text-primary" />
                    <span className="font-semibold text-primary group-hover/item:underline">
                      View All Features
                    </span>
                    <ArrowRight className="w-4 h-4 text-primary group-hover/item:translate-x-1 transition-transform duration-200" />
                  </div>
                </div>
              </div>
              <button
                onClick={() =>
                  document
                    .getElementById("how-it-works")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
                className="text-sm xl:text-base text-muted-foreground hover:text-foreground transition-all duration-300 bg-transparent border-none cursor-pointer px-3 py-2 rounded-lg hover:bg-muted/50 font-medium btn-smooth"
              >
                How it works
              </button>
              <button
                onClick={() =>
                  alert(
                    "Pricing section coming soon! Contact us for custom pricing.",
                  )
                }
                className="text-sm xl:text-base text-muted-foreground hover:text-foreground transition-all duration-300 bg-transparent border-none cursor-pointer px-3 py-2 rounded-lg hover:bg-muted/50 font-medium btn-smooth"
              >
                Pricing
              </button>
              <button
                onClick={() =>
                  document
                    .getElementById("testimonials")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
                className="text-sm xl:text-base text-muted-foreground hover:text-foreground transition-all duration-300 bg-transparent border-none cursor-pointer px-3 py-2 rounded-lg hover:bg-muted/50 font-medium btn-smooth"
              >
                Success Stories
              </button>
            </div>

            {/* Desktop Auth Buttons */}
            <div className="hidden md:flex items-center space-x-3 lg:space-x-4 animate-fade-in-scale animate-stagger-1">
              <Button
                variant="ghost"
                size="sm"
                className="text-sm xl:text-base font-medium px-4 py-2 btn-smooth hover:bg-muted/50"
              >
                Sign In
              </Button>
              <Link to="/dashboard">
                <Button
                  size="sm"
                  className="gradient-brand border-0 text-sm xl:text-base font-medium px-4 lg:px-6 py-2 btn-smooth"
                >
                  Get Started
                </Button>
              </Link>
            </div>

            {/* Mobile Menu */}
            <div className="lg:hidden animate-fade-in-scale">
              <Sheet>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-2 hover:bg-muted/50 btn-smooth"
                  >
                    <Menu className="w-5 h-5 md:w-6 md:h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent
                  side="right"
                  className="w-80 sm:w-96 mobile-nav-transition"
                >
                  <div className="flex flex-col space-y-6 mt-6">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-xl font-bold gradient-text">
                        InfluenceHub
                      </span>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="font-semibold mb-3 text-foreground">
                          Features
                        </div>
                        <div className="space-y-3 pl-4">
                          <div
                            className="flex items-center space-x-3 cursor-pointer hover:bg-muted/50 p-2 rounded transition-colors"
                            onClick={() => setIsSmartMatchingOpen(true)}
                          >
                            <div className="w-6 h-6 gradient-brand rounded flex items-center justify-center">
                              <Brain className="w-3 h-3 text-white" />
                            </div>
                            <span className="text-sm text-muted-foreground">
                              Smart Matching
                            </span>
                          </div>
                          <div
                            className="flex items-center space-x-3 cursor-pointer hover:bg-muted/50 p-2 rounded transition-colors"
                            onClick={() => {
                              document
                                .getElementById("features")
                                ?.scrollIntoView({ behavior: "smooth" });
                            }}
                          >
                            <div className="w-6 h-6 gradient-brand rounded flex items-center justify-center">
                              <BarChart3 className="w-3 h-3 text-white" />
                            </div>
                            <span className="text-sm text-muted-foreground">
                              Real-time Analytics
                            </span>
                          </div>
                          <div
                            className="flex items-center space-x-3 cursor-pointer hover:bg-muted/50 p-2 rounded transition-colors"
                            onClick={() => {
                              document
                                .getElementById("features")
                                ?.scrollIntoView({ behavior: "smooth" });
                            }}
                          >
                            <div className="w-6 h-6 gradient-brand rounded flex items-center justify-center">
                              <Target className="w-3 h-3 text-white" />
                            </div>
                            <span className="text-sm text-muted-foreground">
                              Campaign Management
                            </span>
                          </div>
                          <div
                            className="flex items-center space-x-3 cursor-pointer hover:bg-muted/50 p-2 rounded transition-colors"
                            onClick={() => {
                              document
                                .getElementById("features")
                                ?.scrollIntoView({ behavior: "smooth" });
                            }}
                          >
                            <div className="w-6 h-6 gradient-brand rounded flex items-center justify-center">
                              <Shield className="w-3 h-3 text-white" />
                            </div>
                            <span className="text-sm text-muted-foreground">
                              Quality Assurance
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          document
                            .getElementById("how-it-works")
                            ?.scrollIntoView({ behavior: "smooth" });
                        }}
                        className="block text-left w-full text-muted-foreground hover:text-foreground transition-colors py-2 bg-transparent border-none cursor-pointer hover:bg-muted/50 px-2 rounded"
                      >
                        How it works
                      </button>
                      <button
                        onClick={() => {
                          alert(
                            "Pricing section coming soon! Contact us for custom pricing.",
                          );
                        }}
                        className="block text-left w-full text-muted-foreground hover:text-foreground transition-colors py-2 bg-transparent border-none cursor-pointer hover:bg-muted/50 px-2 rounded"
                      >
                        Pricing
                      </button>
                      <button
                        onClick={() => {
                          document
                            .getElementById("testimonials")
                            ?.scrollIntoView({ behavior: "smooth" });
                        }}
                        className="block text-left w-full text-muted-foreground hover:text-foreground transition-colors py-2 bg-transparent border-none cursor-pointer hover:bg-muted/50 px-2 rounded"
                      >
                        Success Stories
                      </button>
                    </div>

                    <div className="border-t pt-6 space-y-3">
                      <Button variant="outline" className="w-full btn-smooth">
                        Sign In
                      </Button>
                      <Link to="/dashboard" className="block">
                        <Button className="w-full gradient-brand border-0 btn-smooth">
                          Get Started
                        </Button>
                      </Link>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden animate-fade-in-up">
        <div className="absolute inset-0 gradient-brand opacity-10"></div>
        <div className="container-responsive py-16 md:py-24 lg:py-32 relative">
          <div className="text-center max-w-5xl mx-auto">
            <Badge className="mb-4 md:mb-6 bg-primary/10 text-primary border-primary/20 animate-fade-in-scale">
              <Zap className="w-3 h-3 mr-1" />
              #1 Influencer Marketing Platform
            </Badge>
            <h1 className="responsive-heading font-bold mb-6 md:mb-8 leading-tight animate-fade-in-up animate-stagger-1">
              Connect Brands with
              <span className="gradient-text block">Authentic Influencers</span>
            </h1>
            <p className="responsive-subheading text-muted-foreground mb-8 md:mb-12 max-w-3xl mx-auto animate-fade-in-up animate-stagger-2">
              Transform your marketing strategy with our AI-powered platform
              that matches brands with the perfect influencers for maximum
              impact and authentic engagement.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center animate-fade-in-up animate-stagger-3">
              <Link to="/dashboard">
                <Button
                  size="lg"
                  className="gradient-brand border-0 text-base md:text-lg px-6 md:px-8 py-3 md:py-6 btn-smooth"
                >
                  Start Collaborating
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Button
                size="lg"
                variant="outline"
                className="text-base md:text-lg px-6 md:px-8 py-3 md:py-6 btn-smooth"
              >
                <Play className="w-5 h-5 mr-2" />
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 md:py-16 bg-muted/30">
        <div className="container-responsive">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            <div className="text-center animate-fade-in-scale animate-stagger-1">
              <div className="responsive-subheading font-bold gradient-text mb-2">
                50K+
              </div>
              <div className="text-sm md:text-base text-muted-foreground">
                Active Influencers
              </div>
            </div>
            <div className="text-center animate-fade-in-scale animate-stagger-2">
              <div className="responsive-subheading font-bold gradient-text mb-2">
                2.5M+
              </div>
              <div className="text-sm md:text-base text-muted-foreground">
                Campaigns Launched
              </div>
            </div>
            <div className="text-center animate-fade-in-scale animate-stagger-3">
              <div className="responsive-subheading font-bold gradient-text mb-2">
                95%
              </div>
              <div className="text-sm md:text-base text-muted-foreground">
                Client Satisfaction
              </div>
            </div>
            <div className="text-center animate-fade-in-scale animate-stagger-4">
              <div className="responsive-subheading font-bold gradient-text mb-2">
                $50M+
              </div>
              <div className="text-sm md:text-base text-muted-foreground">
                Campaign Value
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 md:py-24">
        <div className="container-responsive">
          <div className="text-center mb-12 md:mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              Features
            </Badge>
            <h2 className="responsive-subheading font-bold mb-4 md:mb-6">
              Everything You Need to
              <span className="gradient-text block">Scale Your Influence</span>
            </h2>
            <p className="responsive-text text-muted-foreground max-w-3xl mx-auto">
              Our comprehensive platform provides all the tools you need for
              successful influencer marketing campaigns.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            <Card
              className="border-2 hover:border-primary/20 transition-all hover:shadow-lg card-hover cursor-pointer group/card relative overflow-hidden"
              onClick={() => setIsSmartMatchingOpen(true)}
            >
              <CardHeader className="pb-4 relative">
                {/* "Try Now" Badge */}
                <div className="absolute top-3 right-3 bg-primary/10 text-primary px-2 py-1 rounded-full text-xs font-medium">
                  Try Now
                </div>

                <div className="w-12 h-12 md:w-14 md:h-14 gradient-brand rounded-lg flex items-center justify-center mb-4 group-hover/card:scale-110 transition-transform duration-300">
                  <Brain className="w-6 h-6 md:w-7 md:h-7 text-white" />
                </div>
                <CardTitle className="text-lg md:text-xl group-hover/card:text-primary transition-colors duration-300">
                  Smart Matching
                </CardTitle>
                <CardDescription className="text-sm md:text-base">
                  AI-powered influencer discovery and matching based on
                  audience, values, and campaign goals.
                </CardDescription>

                {/* Enhanced CTA */}
                <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover/card:underline">
                  <span>Launch AI Matching</span>
                  <ArrowRight className="w-4 h-4 ml-2 group-hover/card:translate-x-1 transition-transform duration-200" />
                </div>
              </CardHeader>

              {/* Hover Effect Overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </Card>

            <Card
              className="border-2 hover:border-primary/20 transition-all hover:shadow-lg card-hover cursor-pointer group/card relative overflow-hidden"
              onClick={() =>
                alert(
                  "📊 Real-time Analytics Dashboard\n\nView comprehensive campaign metrics, engagement rates, ROI tracking, and performance insights. This feature provides live data visualization and detailed reporting.\n\nComing in full version!",
                )
              }
            >
              <CardHeader className="pb-4 relative">
                <div className="absolute top-3 right-3 bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">
                  Dashboard
                </div>

                <div className="w-12 h-12 md:w-14 md:h-14 gradient-brand rounded-lg flex items-center justify-center mb-4 group-hover/card:scale-110 transition-transform duration-300">
                  <BarChart3 className="w-6 h-6 md:w-7 md:h-7 text-white" />
                </div>
                <CardTitle className="text-lg md:text-xl group-hover/card:text-primary transition-colors duration-300">
                  Real-time Analytics
                </CardTitle>
                <CardDescription className="text-sm md:text-base">
                  Track campaign performance with detailed analytics, engagement
                  metrics, and ROI insights.
                </CardDescription>

                <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover/card:underline">
                  <span>View Analytics</span>
                  <BarChart3 className="w-4 h-4 ml-2 group-hover/card:scale-110 transition-transform duration-200" />
                </div>
              </CardHeader>

              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </Card>

            <Card
              className="border-2 hover:border-primary/20 transition-all hover:shadow-lg card-hover cursor-pointer group/card relative overflow-hidden"
              onClick={() =>
                alert(
                  "🎯 Campaign Management Suite\n\nAutomated workflow tools including:\n• Campaign creation wizard\n• Content approval system\n• Payment processing\n• Timeline management\n• Team collaboration\n\nStreamline your entire campaign process!",
                )
              }
            >
              <CardHeader className="pb-4 relative">
                <div className="absolute top-3 right-3 bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                  Workflow
                </div>

                <div className="w-12 h-12 md:w-14 md:h-14 gradient-brand rounded-lg flex items-center justify-center mb-4 group-hover/card:scale-110 transition-transform duration-300">
                  <Target className="w-6 h-6 md:w-7 md:h-7 text-white" />
                </div>
                <CardTitle className="text-lg md:text-xl group-hover/card:text-primary transition-colors duration-300">
                  Campaign Management
                </CardTitle>
                <CardDescription className="text-sm md:text-base">
                  Streamline your workflow with automated campaign creation,
                  content approval, and payment processing.
                </CardDescription>

                <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover/card:underline">
                  <span>Manage Campaigns</span>
                  <Target className="w-4 h-4 ml-2 group-hover/card:rotate-90 transition-transform duration-200" />
                </div>
              </CardHeader>

              <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </Card>

            <Card
              className="border-2 hover:border-primary/20 transition-all hover:shadow-lg card-hover cursor-pointer group/card relative overflow-hidden"
              onClick={() =>
                alert(
                  "🌍 Global Influencer Network\n\nAccess our worldwide network:\n• 50+ Countries\n• 25+ Languages\n• All major platforms (Instagram, TikTok, YouTube, Twitter)\n• 100+ Niches and categories\n• Verified authentic accounts\n\nExpand your reach globally!",
                )
              }
            >
              <CardHeader className="pb-4 relative">
                <div className="absolute top-3 right-3 bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-medium">
                  Worldwide
                </div>

                <div className="w-12 h-12 md:w-14 md:h-14 gradient-brand rounded-lg flex items-center justify-center mb-4 group-hover/card:scale-110 transition-transform duration-300">
                  <Globe className="w-6 h-6 md:w-7 md:h-7 text-white" />
                </div>
                <CardTitle className="text-lg md:text-xl group-hover/card:text-primary transition-colors duration-300">
                  Global Reach
                </CardTitle>
                <CardDescription className="text-sm md:text-base">
                  Access influencers worldwide across all major social platforms
                  and niches.
                </CardDescription>

                <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover/card:underline">
                  <span>Explore Network</span>
                  <Globe className="w-4 h-4 ml-2 group-hover/card:rotate-180 transition-transform duration-500" />
                </div>
              </CardHeader>

              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </Card>

            <Card
              className="border-2 hover:border-primary/20 transition-all hover:shadow-lg card-hover cursor-pointer group/card relative overflow-hidden"
              onClick={() =>
                alert(
                  "📈 Performance Tracking Suite\n\nAdvanced monitoring tools:\n• ROI Calculator\n• Conversion Tracking\n• Brand Sentiment Analysis\n• Engagement Rate Monitoring\n• KPI Dashboards\n• Custom Reports\n\nOptimize your campaign performance!",
                )
              }
            >
              <CardHeader className="pb-4 relative">
                <div className="absolute top-3 right-3 bg-orange-100 text-orange-700 px-2 py-1 rounded-full text-xs font-medium">
                  Metrics
                </div>

                <div className="w-12 h-12 md:w-14 md:h-14 gradient-brand rounded-lg flex items-center justify-center mb-4 group-hover/card:scale-110 transition-transform duration-300">
                  <TrendingUp className="w-6 h-6 md:w-7 md:h-7 text-white" />
                </div>
                <CardTitle className="text-lg md:text-xl group-hover/card:text-primary transition-colors duration-300">
                  Performance Tracking
                </CardTitle>
                <CardDescription className="text-sm md:text-base">
                  Monitor KPIs, conversion rates, and brand sentiment with
                  advanced tracking tools.
                </CardDescription>

                <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover/card:underline">
                  <span>Track Performance</span>
                  <TrendingUp className="w-4 h-4 ml-2 group-hover/card:scale-110 transition-transform duration-200" />
                </div>
              </CardHeader>

              <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </Card>

            <Card
              className="border-2 hover:border-primary/20 transition-all hover:shadow-lg card-hover cursor-pointer group/card relative overflow-hidden"
              onClick={() =>
                alert(
                  "🛡️ Quality Assurance System\n\nEnsure authenticity with:\n• AI-powered fraud detection\n• Follower authenticity verification\n• Content quality analysis\n• Engagement authenticity checks\n• Brand safety monitoring\n• Compliance verification\n\nProtect your brand reputation!",
                )
              }
            >
              <CardHeader className="pb-4 relative">
                <div className="absolute top-3 right-3 bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-medium">
                  Security
                </div>

                <div className="w-12 h-12 md:w-14 md:h-14 gradient-brand rounded-lg flex items-center justify-center mb-4 group-hover/card:scale-110 transition-transform duration-300">
                  <Shield className="w-6 h-6 md:w-7 md:h-7 text-white" />
                </div>
                <CardTitle className="text-lg md:text-xl group-hover/card:text-primary transition-colors duration-300">
                  Quality Assurance
                </CardTitle>
                <CardDescription className="text-sm md:text-base">
                  Ensure authentic engagement with our fraud detection and
                  content verification systems.
                </CardDescription>

                <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover/card:underline">
                  <span>Learn Security</span>
                  <Shield className="w-4 h-4 ml-2 group-hover/card:scale-110 transition-transform duration-200" />
                </div>
              </CardHeader>

              <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-16 md:py-24 bg-muted/30">
        <div className="container-responsive">
          <div className="text-center mb-12 md:mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              How It Works
            </Badge>
            <h2 className="responsive-subheading font-bold mb-4 md:mb-6">
              Simple Process,
              <span className="gradient-text block">Powerful Results</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            <div className="text-center animate-fade-in-up animate-stagger-1">
              <div className="w-16 h-16 md:w-20 md:h-20 gradient-brand rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl md:text-3xl font-bold text-white">
                  1
                </span>
              </div>
              <h3 className="text-lg md:text-xl font-semibold mb-4">
                Create Your Campaign
              </h3>
              <p className="text-sm md:text-base text-muted-foreground">
                Define your goals, target audience, and budget. Our AI will help
                optimize your campaign strategy.
              </p>
            </div>
            <div className="text-center animate-fade-in-up animate-stagger-2">
              <div className="w-16 h-16 md:w-20 md:h-20 gradient-brand rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl md:text-3xl font-bold text-white">
                  2
                </span>
              </div>
              <h3 className="text-lg md:text-xl font-semibold mb-4">
                Get Matched
              </h3>
              <p className="text-sm md:text-base text-muted-foreground">
                Our smart algorithm finds the perfect influencers for your brand
                based on audience alignment and engagement quality.
              </p>
            </div>
            <div className="text-center animate-fade-in-up animate-stagger-3">
              <div className="w-16 h-16 md:w-20 md:h-20 gradient-brand rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl md:text-3xl font-bold text-white">
                  3
                </span>
              </div>
              <h3 className="text-lg md:text-xl font-semibold mb-4">
                Launch & Track
              </h3>
              <p className="text-sm md:text-base text-muted-foreground">
                Collaborate seamlessly, approve content, and track real-time
                performance metrics to maximize your ROI.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-16 md:py-24">
        <div className="container-responsive">
          <div className="text-center mb-12 md:mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              Success Stories
            </Badge>
            <h2 className="responsive-subheading font-bold mb-4 md:mb-6">
              Loved by Brands &
              <span className="gradient-text block">Influencers Worldwide</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            <Card className="border-2 card-hover">
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback>SM</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">Sarah Martinez</div>
                    <div className="text-sm text-muted-foreground">
                      Fashion Influencer
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>
                <p className="text-sm md:text-base text-muted-foreground">
                  "InfluenceHub transformed my collaborations. The platform
                  makes it so easy to connect with brands that align with my
                  values and audience."
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 card-hover">
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback>DK</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">David Kim</div>
                    <div className="text-sm text-muted-foreground">
                      Marketing Director, TechCorp
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>
                <p className="text-sm md:text-base text-muted-foreground">
                  "We saw a 300% increase in engagement and 150% boost in
                  conversions within just 3 months. The ROI has been
                  incredible."
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 card-hover">
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback>EJ</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">Emma Johnson</div>
                    <div className="text-sm text-muted-foreground">
                      Lifestyle Creator
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>
                <p className="text-sm md:text-base text-muted-foreground">
                  "The analytics and insights help me understand my audience
                  better and create more engaging content. It's a game-changer!"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 gradient-brand">
        <div className="container-responsive text-center">
          <h2 className="responsive-subheading font-bold text-white mb-6">
            Ready to Amplify Your Influence?
          </h2>
          <p className="responsive-text text-white/90 mb-8 md:mb-12 max-w-3xl mx-auto">
            Join thousands of successful brands and influencers who trust
            InfluenceHub to grow their business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center">
            <Link to="/dashboard">
              <Button
                size="lg"
                variant="secondary"
                className="text-base md:text-lg px-6 md:px-8 py-3 md:py-6 btn-smooth"
              >
                Start Your Campaign
                <Heart className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="text-base md:text-lg px-6 md:px-8 py-3 md:py-6 border-white/20 text-white hover:bg-white/10 btn-smooth"
            >
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 md:py-16 border-t">
        <div className="container-responsive">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg md:text-xl font-bold">
                  InfluenceHub
                </span>
              </div>
              <p className="text-sm md:text-base text-muted-foreground">
                The leading platform connecting brands with authentic
                influencers for impactful marketing campaigns.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm md:text-base text-muted-foreground">
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Features
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Pricing
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Analytics
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    API
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm md:text-base text-muted-foreground">
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Blog
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Case Studies
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Help Center
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Community
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm md:text-base text-muted-foreground">
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    About
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Careers
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Contact
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-foreground transition-colors"
                  >
                    Privacy
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-sm md:text-base text-muted-foreground">
            <p>&copy; 2024 InfluenceHub. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Smart Matching Dialog */}
      <Dialog open={isSmartMatchingOpen} onOpenChange={setIsSmartMatchingOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center">
                <Brain className="w-4 h-4 text-white" />
              </div>
              <span>AI-Powered Smart Matching</span>
            </DialogTitle>
            <DialogDescription>
              Let our AI find the perfect influencers for your brand. Fill out
              the details below and we'll match you with influencers who align
              with your brand values and target audience.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Brand Information */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center">
                <Target className="w-4 h-4 mr-2 text-primary" />
                Brand Information
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Brand Name
                  </label>
                  <Input
                    placeholder="Enter your brand name"
                    value={matchingForm.brandName}
                    onChange={(e) =>
                      setMatchingForm({
                        ...matchingForm,
                        brandName: e.target.value,
                      })
                    }
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Industry
                  </label>
                  <Select
                    value={matchingForm.industry}
                    onValueChange={(value) =>
                      setMatchingForm({ ...matchingForm, industry: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fashion">Fashion & Beauty</SelectItem>
                      <SelectItem value="tech">Technology</SelectItem>
                      <SelectItem value="fitness">Health & Fitness</SelectItem>
                      <SelectItem value="food">Food & Beverage</SelectItem>
                      <SelectItem value="travel">Travel & Lifestyle</SelectItem>
                      <SelectItem value="gaming">
                        Gaming & Entertainment
                      </SelectItem>
                      <SelectItem value="business">
                        Business & Finance
                      </SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="home">Home & Garden</SelectItem>
                      <SelectItem value="automotive">Automotive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Campaign Details */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center">
                <BarChart3 className="w-4 h-4 mr-2 text-primary" />
                Campaign Details
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Budget Range
                  </label>
                  <Select
                    value={matchingForm.budget}
                    onValueChange={(value) =>
                      setMatchingForm({ ...matchingForm, budget: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select budget" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1k-5k">$1,000 - $5,000</SelectItem>
                      <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                      <SelectItem value="10k-25k">$10,000 - $25,000</SelectItem>
                      <SelectItem value="25k-50k">$25,000 - $50,000</SelectItem>
                      <SelectItem value="50k-100k">
                        $50,000 - $100,000
                      </SelectItem>
                      <SelectItem value="100k+">$100,000+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Preferred Platforms
                  </label>
                  <Select
                    value={matchingForm.preferredPlatforms}
                    onValueChange={(value) =>
                      setMatchingForm({
                        ...matchingForm,
                        preferredPlatforms: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select platforms" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="tiktok">TikTok</SelectItem>
                      <SelectItem value="youtube">YouTube</SelectItem>
                      <SelectItem value="twitter">Twitter/X</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="all">All Platforms</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Target Audience */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center">
                <Users className="w-4 h-4 mr-2 text-primary" />
                Target Audience
              </h4>
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Describe Your Target Audience
                </label>
                <Textarea
                  placeholder="e.g., Women aged 25-35, interested in sustainable fashion, living in urban areas..."
                  value={matchingForm.targetAudience}
                  onChange={(e) =>
                    setMatchingForm({
                      ...matchingForm,
                      targetAudience: e.target.value,
                    })
                  }
                  rows={3}
                />
              </div>
            </div>

            {/* Campaign Goals */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center">
                <TrendingUp className="w-4 h-4 mr-2 text-primary" />
                Campaign Goals
              </h4>
              <div>
                <label className="text-sm font-medium mb-2 block">
                  What are your main objectives?
                </label>
                <Textarea
                  placeholder="e.g., Increase brand awareness, drive website traffic, boost sales, launch new product..."
                  value={matchingForm.campaignGoals}
                  onChange={(e) =>
                    setMatchingForm({
                      ...matchingForm,
                      campaignGoals: e.target.value,
                    })
                  }
                  rows={3}
                />
              </div>
            </div>

            {/* AI Matching Results Preview */}
            <div className="space-y-4 border-t pt-4">
              <h4 className="font-semibold flex items-center">
                <Sparkles className="w-4 h-4 mr-2 text-primary" />
                AI Matching Preview
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-2 border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg" />
                        <AvatarFallback>SF</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">@style_fashionista</div>
                        <div className="text-sm text-muted-foreground">
                          Fashion
                        </div>
                      </div>
                      <Badge className="ml-auto bg-green-100 text-green-800">
                        95% Match
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-sm">
                      <div>
                        <div className="font-semibold">125K</div>
                        <div className="text-muted-foreground">Followers</div>
                      </div>
                      <div>
                        <div className="font-semibold">4.8%</div>
                        <div className="text-muted-foreground">Engagement</div>
                      </div>
                      <div>
                        <div className="font-semibold">$800</div>
                        <div className="text-muted-foreground">Per Post</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg" />
                        <AvatarFallback>TI</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">@tech_innovator</div>
                        <div className="text-sm text-muted-foreground">
                          Technology
                        </div>
                      </div>
                      <Badge className="ml-auto bg-green-100 text-green-800">
                        92% Match
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-sm">
                      <div>
                        <div className="font-semibold">89K</div>
                        <div className="text-muted-foreground">Followers</div>
                      </div>
                      <div>
                        <div className="font-semibold">6.2%</div>
                        <div className="text-muted-foreground">Engagement</div>
                      </div>
                      <div>
                        <div className="font-semibold">$600</div>
                        <div className="text-muted-foreground">Per Post</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                Complete the form above to see personalized matches for your
                brand
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => setIsSmartMatchingOpen(false)}
              className="flex-1 btn-smooth"
            >
              Cancel
            </Button>
            <Button
              className="gradient-brand border-0 flex-1 btn-smooth"
              onClick={() => {
                if (!matchingForm.brandName || !matchingForm.industry) {
                  alert(
                    "Please fill in at least your brand name and industry to continue.",
                  );
                  return;
                }
                alert(
                  `🎯 Smart Matching initiated for ${matchingForm.brandName}!\n\nOur AI is now analyzing 50,000+ influencers to find your perfect matches. You'll receive personalized recommendations within 24 hours.\n\nNext step: Create a free account to access your matches!`,
                );
                setIsSmartMatchingOpen(false);
              }}
            >
              <Brain className="w-4 h-4 mr-2" />
              Find My Matches
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
